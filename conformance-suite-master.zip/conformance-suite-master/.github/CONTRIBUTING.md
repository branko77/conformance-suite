The github repository is a read-only mirror. Please do not open pull
requests on github, and instead create them on gitlab:

https://gitlab.com/openid/conformance-suite
